﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IMGUI : MonoBehaviour
{

    private Rect bloodBar;
    private float barUpLength = 170f;

    void Start()
    {
        bloodBar = new Rect(0, 0, 360, 20);
    }

    void OnGUI()
    {
        Vector2 player2DPosition = Camera.main.WorldToScreenPoint(transform.position);
        player2DPosition.y = Screen.height - player2DPosition.y - barUpLength - 300;
        bloodBar.center = player2DPosition + new Vector2(0, 0);
        if (player2DPosition.x > Screen.width || player2DPosition.y > Screen.height
            || player2DPosition.x < 0 || player2DPosition.y < 0)
        {

        }
        else
        {
            GUI.HorizontalScrollbar(bloodBar, 0.0f, 1.0f, 0.0f, 1.0f);
        }
    }
}
