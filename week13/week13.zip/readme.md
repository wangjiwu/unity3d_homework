# week13作业说明

实现两种血条， 视频开始是共用UGUI， 然后用IMGUI